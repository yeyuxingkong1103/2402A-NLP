import os, sys
sys.path.insert(0, "/home/lenovo/contract-rag")
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from src.online.chat_service import answer
from src.memory.mysql_client import list_roles

app = FastAPI(title="合同律师 RAG 系统", version="1.0")


class ChatReq(BaseModel):
    user_id: str = "anonymous"
    role_name: str = "合同律师"
    question: str


class ChatResp(BaseModel):
    answer: str
    sources: list


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/roles")
def get_roles():
    return {"roles": list_roles()}


@app.post("/chat", response_model=ChatResp)
def chat_api(req: ChatReq):
    try:
        reply, docs = answer(req.user_id, req.question, role_name=req.role_name)
        return ChatResp(
            answer=reply,
            sources=[d["text"][:100] for d in docs],
        )
    except Exception as e:
        raise HTTPException(500, f"Error: {str(e)}")


STATIC_DIR = "/home/lenovo/contract-rag/src/api/static"
if os.path.exists(STATIC_DIR):
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

    @app.get("/")
    def index():
        return FileResponse(os.path.join(STATIC_DIR, "index.html"))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
