import mineru

PDF_PATH = "/home/lenovo/contract-rag/data/laws/中华人民共和国民法典合同编精选与实务指引.pdf"


if __name__ == "__main__":
    result = mineru.parse(PDF_PATH, tier="standard")

    print("markdown 类型:", type(result.markdown))
    print("是否可调用:", callable(result.markdown))

    if callable(result.markdown):
        md = result.markdown()
        print(f"调用后长度: {len(md)}")
        print(f"前 200 字:\n{md[:200]}")
    else:
        print(f"直接访问长度: {len(result.markdown)}")
        print(f"前 200 字:\n{result.markdown[:200]}")
