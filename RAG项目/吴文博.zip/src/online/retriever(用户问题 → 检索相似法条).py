import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from config import (MILVUS_HOST, MILVUS_PORT, MILVUS_COLLECTION, BGE_M3_PATH)
from pymilvus import connections, Collection
from sentence_transformers import SentenceTransformer


class Retriever:
    def __init__(self):
        connections.connect("default", host=MILVUS_HOST, port=str(MILVUS_PORT))
        self.col = Collection(MILVUS_COLLECTION)
        self.col.load()
        print("加载 BGE-m3...")
        self.model = SentenceTransformer(BGE_M3_PATH, device="cuda")

    def search(self, query, top_k=3):
        q_vec = self.model.encode([query], normalize_embeddings=True).tolist()
        results = self.col.search(
            data=q_vec,
            anns_field="vector",
            param={"metric_type": "COSINE", "params": {"nprobe": 16}},
            limit=top_k,
            output_fields=["text", "source", "chunk_id"],
        )
        hits = []
        for r in results[0]:
            hits.append({
                "text": r.entity.get("text"),
                "source": r.entity.get("source"),
                "chunk_id": r.entity.get("chunk_id"),
                "score": r.score,
            })
        return hits


if __name__ == "__main__":
    r = Retriever()
    q = "定金最多能收多少？"
    print(f"\n查询: {q}\n")
    hits = r.search(q, top_k=3)
    for i, h in enumerate(hits, 1):
        print(f"--- 结果 {i} (score={h['score']:.4f}) ---")
        print(f"来源: {h['source']}")
        print(f"内容: {h['text'][:250]}...\n")
