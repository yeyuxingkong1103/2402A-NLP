import os, sys, json
sys.path.insert(0, "/home/lenovo/contract-rag")
from config import REDIS_HOST, REDIS_PORT, REDIS_DB
import redis

r = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=REDIS_DB,
                decode_responses=True)


def save_message(user_id, role, content, max_len=20):
    key = f"chat:{user_id}"
    r.rpush(key, json.dumps({"role": role, "content": content}, ensure_ascii=False))
    r.ltrim(key, -max_len, -1)
    r.expire(key, 3600 * 24)


def get_history(user_id):
    key = f"chat:{user_id}"
    items = r.lrange(key, 0, -1)
    return [json.loads(i) for i in items]


def clear_history(user_id):
    r.delete(f"chat:{user_id}")


def format_history(user_id, max_turns=3):
    history = get_history(user_id)
    history = history[-max_turns * 2:]
    lines = []
    for h in history:
        who = "用户" if h["role"] == "user" else "律师"
        lines.append(f"{who}: {h['content']}")
    return "\n".join(lines)


if __name__ == "__main__":
    user = "test_user"
    clear_history(user)
    save_message(user, "user", "定金最多能收多少？")
    save_message(user, "assistant", "不超过20%。")
    save_message(user, "user", "超过会怎样？")
    save_message(user, "assistant", "超过部分不产生定金效力。")
    print("历史消息:")
    for h in get_history(user):
        print(f"  {h['role']}: {h['content']}")
    print("\n格式化:")
    print(format_history(user))
