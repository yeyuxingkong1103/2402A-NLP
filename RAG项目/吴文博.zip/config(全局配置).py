MYSQL_HOST = "127.0.0.1"
MYSQL_PORT = 3307
MYSQL_USER = "rag_user"
MYSQL_PASSWORD = "rag_pass123"
MYSQL_DB = "rag_db"

REDIS_HOST = "127.0.0.1"
REDIS_PORT = 6379
REDIS_DB = 0

MILVUS_HOST = "127.0.0.1"
MILVUS_PORT = 19530
MILVUS_COLLECTION = "contract_kb"
MILVUS_DIM = 1024

BGE_M3_PATH = "/home/lenovo/models/bge-m3"
BGE_RERANKER_PATH = "/home/lenovo/models/bge-reranker-base"
QWEN_PATH = "/home/lenovo/models/Qwen3-0.6B"

DATA_DIR = "data/laws"
PARSED_DIR = "data/parsed"
CHUNK_DIR = "chunked"
