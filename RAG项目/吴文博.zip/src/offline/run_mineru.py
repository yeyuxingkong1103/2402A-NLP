import os, sys
sys.path.insert(0, "/home/lenovo/contract-rag")
import mineru

PDF_PATH = "/home/lenovo/contract-rag/data/laws/中华人民共和国民法典合同编精选与实务指引.pdf"
OUTPUT_DIR = "/home/lenovo/contract-rag/data/mineru_output"


def run_mineru():
    print("=" * 50)
    print("MinerU Python API 解析")
    print("=" * 50)

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    result = mineru.parse(PDF_PATH, tier="standard")
    print(f"✅ 解析完成: {type(result).__name__}")
    print()

    # 关键：markdown 是方法，要调用
    md_content = result.markdown()

    md_path = os.path.join(OUTPUT_DIR, "中华人民共和国民法典合同编精选与实务指引.md")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(md_content)
    print(f"✅ Markdown 保存: {md_path}")
    print(f"   长度: {len(md_content)} 字")
    print()

    # 保存 JSON
    json_content = result.to_json()
    json_path = os.path.join(OUTPUT_DIR, "中华人民共和国民法典合同编精选与实务指引.json")
    with open(json_path, "w", encoding="utf-8") as f:
        f.write(json_content)
    print(f"✅ JSON 保存: {json_path}")
    print()

    print("=== Markdown 前 500 字 ===")
    print(md_content[:500])


if __name__ == "__main__":
    run_mineru()
