import os, sys, json, re
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from config import PARSED_DIR


def parse_mineru_md(md_path, source_name):
    with open(md_path, "r", encoding="utf-8") as f:
        content = f.read()
    sections = re.split(r"\n(?=#{2,3} )", content)
    pages = []
    for i, sec in enumerate(sections):
        if len(sec.strip()) < 20:
            continue
        pages.append({"page": i + 1, "text": sec.strip()})
    return {"source": source_name, "pages": pages}


def load_mineru_output(mineru_dir, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    md_files = []
    for root, dirs, files in os.walk(mineru_dir):
        for f in files:
            if f.endswith(".md"):
                md_files.append(os.path.join(root, f))
    if not md_files:
        print(f"⚠️  未找到 .md 文件于 {mineru_dir}")
        return
    for md_path in md_files:
        fname = os.path.basename(md_path)
        source = fname.replace(".md", ".pdf")
        print(f"处理: {fname}")
        data = parse_mineru_md(md_path, source)
        out = os.path.join(output_dir, source.replace(".pdf", ".json"))
        with open(out, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"  -> {out} ({len(data['pages'])} 段)")


if __name__ == "__main__":
    load_mineru_output("data/mineru_output", PARSED_DIR)
    print("✅ MinerU 结果转换完成")
