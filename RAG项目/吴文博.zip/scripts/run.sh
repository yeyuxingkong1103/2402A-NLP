#!/bin/bash
set -e
cd "$(dirname "$0")/.."
PROJECT_DIR=$(pwd)

echo "=========================================="
echo "  Contract RAG 系统 - 启动"
echo "=========================================="

echo "[1/3] 启动 Docker 容器..."
docker start milvus-etcd milvus-minio milvus-standalone mysql redis 2>/dev/null || true
sleep 10

echo "[2/3] 激活 Python 环境..."
source ~/nlp_env/bin/activate
export PYTHONPATH=$PROJECT_DIR:$PYTHONPATH

echo "[3/3] 启动 FastAPI..."
pkill -f "uvicorn src.api.main" 2>/dev/null || true
sleep 2

mkdir -p logs
nohup uvicorn src.api.main:app --host 0.0.0.0 --port 8000 > logs/api.log 2>&1 &
echo $! > .api.pid

sleep 8
if ps -p $(cat .api.pid) > /dev/null; then
    echo "✅ FastAPI 已启动 (PID: $(cat .api.pid))"
    echo "访问 http://localhost:8000/docs"
else
    echo "❌ 启动失败，看 logs/api.log"
    exit 1
fi
