import os, sys
sys.path.insert(0, "/home/lenovo/contract-rag")

PDF_PATH = "/home/lenovo/contract-rag/data/laws/中华人民共和国民法典合同编精选与实务指引.pdf"
MINERU_OUT = "/home/lenovo/contract-rag/data/mineru_output"


def step1_mineru():
    print("=" * 60)
    print("【Step 1/4】MinerU 多模态解析")
    print("=" * 60)

    import mineru
    os.makedirs(MINERU_OUT, exist_ok=True)

    result = mineru.parse(PDF_PATH, tier="standard")
    md_content = result.markdown()

    md_path = os.path.join(MINERU_OUT, "中华人民共和国民法典合同编精选与实务指引.md")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(md_content)

    print(f"✅ Markdown 保存: {md_path}")
    print(f"   长度: {len(md_content)} 字\n")


def step2_loader():
    print("=" * 60)
    print("【Step 2/4】Markdown → JSON")
    print("=" * 60)

    from src.offline.mineru_loader import load_mineru_output
    from config import PARSED_DIR
    load_mineru_output(MINERU_OUT, PARSED_DIR)
    print("✅ JSON 完成\n")


def step3_chunker():
    print("=" * 60)
    print("【Step 3/4】JSON → 分块")
    print("=" * 60)

    from src.offline.chunker import chunk_all
    from config import PARSED_DIR, CHUNK_DIR
    chunk_all(PARSED_DIR, os.path.join(CHUNK_DIR, "all_chunks.json"))
    print("✅ 分块完成\n")


def step4_insert_milvus():
    print("=" * 60)
    print("【Step 4/4】分块 → Milvus 向量库")
    print("=" * 60)

    from src.offline.insert_milvus import insert_chunks
    from config import CHUNK_DIR
    insert_chunks(os.path.join(CHUNK_DIR, "all_chunks.json"))
    print("✅ 入库完成\n")


if __name__ == "__main__":
    print("\n🚀 离线管道启动（4 步）\n")
    step1_mineru()
    step2_loader()
    step3_chunker()
    step4_insert_milvus()
    print("🎉 离线管道全部完成！")
