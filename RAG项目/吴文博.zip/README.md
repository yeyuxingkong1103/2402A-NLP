# 合同律师 RAG 系统

基于 RAG（检索增强生成）的合同法律师聊天机器人。

## 功能

- MinerU 多模态解析（表格完美转换）
- BGE-m3 向量化（GPU 加速）
- Milvus 向量库
- BGE-reranker 重排
- Qwen3-0.6B 生成（本地部署）
- 多轮对话（Redis 记忆）
- 多角色（MySQL 管理）
- FastAPI 接口

## 架构

离线：PDF -> MinerU VLM -> Markdown -> 分块 -> BGE-m3 -> Milvus

在线：用户提问 -> 检索 -> 重排 -> 拼提示词 -> Qwen3 生成 -> 返回

## 快速开始

启动：bash scripts/run.sh

停止：bash scripts/shutdown.sh

访问：http://localhost:8000/docs

## API

- GET /health - 健康检查
- GET /roles - 列出角色
- POST /chat - 问答

## 技术栈

- 大模型：Qwen3-0.6B
- 向量模型：BGE-m3
- 重排模型：BGE-reranker-base
- 向量库：Milvus 3.x
- 关系库：MySQL 8.0
- 缓存：Redis 7.2
- 后端：FastAPI
- PDF 解析：MinerU VLM

## License

MIT
