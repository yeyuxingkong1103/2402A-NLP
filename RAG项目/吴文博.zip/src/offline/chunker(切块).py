import json, os, sys
sys.path.insert(0, "/home/lenovo/contract-rag")
from config import PARSED_DIR, CHUNK_DIR


def chunk_file(json_path):
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    source = data["source"]
    full_text = "\n".join([p["text"] for p in data["pages"]])

    lines = full_text.split("\n")
    chunks = []
    current = ""

    for line in lines:
        # 表格行独立成块
        if line.strip().startswith("|"):
            if current.strip():
                chunks.append(current.strip())
                current = ""
            chunks.append(line.strip())
        else:
            current += line + "\n"
            if len(current) > 500:
                chunks.append(current.strip())
                current = ""

    if current.strip():
        chunks.append(current.strip())

    # 合并太短的块
    merged = []
    buf = ""
    for c in chunks:
        if len(c) < 20:
            buf += c + "\n"
        else:
            if buf:
                merged.append(buf.strip())
                buf = ""
            merged.append(c)
    if buf:
        merged.append(buf.strip())

    return [{"id": f"{source}_{idx}", "text": c.strip(),
             "source": source, "chunk_id": idx}
            for idx, c in enumerate(merged) if len(c.strip()) >= 15]


def chunk_all(input_dir, output_path):
    all_chunks = []
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    for fname in os.listdir(input_dir):
        if fname.endswith(".json"):
            all_chunks.extend(chunk_file(os.path.join(input_dir, fname)))
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(all_chunks, f, ensure_ascii=False, indent=2)
    print(f"✅ 共 {len(all_chunks)} 个分块 -> {output_path}")


if __name__ == "__main__":
    chunk_all(PARSED_DIR, os.path.join(CHUNK_DIR, "all_chunks.json"))
