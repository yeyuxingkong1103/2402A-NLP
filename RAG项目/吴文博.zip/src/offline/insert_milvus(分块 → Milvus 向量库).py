import json, os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from config import (MILVUS_HOST, MILVUS_PORT, MILVUS_COLLECTION,
                    MILVUS_DIM, BGE_M3_PATH, CHUNK_DIR)
from pymilvus import (connections, FieldSchema, CollectionSchema,
                      DataType, Collection, utility)
from sentence_transformers import SentenceTransformer


def init_milvus():
    connections.connect("default", host=MILVUS_HOST, port=str(MILVUS_PORT))
    if utility.has_collection(MILVUS_COLLECTION):
        col = Collection(MILVUS_COLLECTION)
        col.load()
        return col
    fields = [
        FieldSchema("id", DataType.INT64, is_primary=True, auto_id=True),
        FieldSchema("chunk_id", DataType.VARCHAR, max_length=256),
        FieldSchema("text", DataType.VARCHAR, max_length=8192),
        FieldSchema("source", DataType.VARCHAR, max_length=256),
        FieldSchema("vector", DataType.FLOAT_VECTOR, dim=MILVUS_DIM),
    ]
    col = Collection(MILVUS_COLLECTION, CollectionSchema(fields))
    col.create_index("vector", {
        "index_type": "IVF_FLAT", "metric_type": "COSINE",
        "params": {"nlist": 128}})
    col.load()
    return col


def insert_chunks(json_path):
    with open(json_path, "r", encoding="utf-8") as f:
        chunks = json.load(f)
    print(f"共 {len(chunks)} 个分块")
    print("加载 BGE-m3...")
    model = SentenceTransformer(BGE_M3_PATH, device="cuda")
    col = init_milvus()
    texts = [c["text"] for c in chunks]
    print("GPU 向量化...")
    embs = model.encode(texts, batch_size=16, normalize_embeddings=True)
    col.insert([
        [str(c["chunk_id"]) for c in chunks],
        [c["text"][:8000] for c in chunks],
        [c["source"] for c in chunks],
        embs.tolist(),
    ])
    col.flush()
    print(f"✅ 入库 {len(chunks)} 条 -> {MILVUS_COLLECTION}")


if __name__ == "__main__":
    insert_chunks(os.path.join(CHUNK_DIR, "all_chunks.json"))
