# ============================================================
# 文件：hybrid_retriever.py
# 作用：混合检索（向量 + BM25 + RRF 融合）
# ============================================================

import os, sys
sys.path.insert(0, "/home/lenovo/contract-rag")
from src.online.retriever import Retriever          # 向量检索
from src.online.bm25_retriever import BM25Retriever # BM25 检索


def rrf_fusion(vector_hits, bm25_hits, k=60):
    """
    RRF（Reciprocal Rank Fusion）融合
    公式：score = Σ 1 / (k + rank)
    把两个列表的排名加起来
    """
    scores = {}
    data = {}

    # 向量检索的排名
    for rank, h in enumerate(vector_hits):
        key = (h["source"], h["chunk_id"])
        scores[key] = scores.get(key, 0) + 1.0 / (k + rank + 1)
        data[key] = h

    # BM25 检索的排名
    for rank, h in enumerate(bm25_hits):
        key = (h["source"], h["chunk_id"])
        scores[key] = scores.get(key, 0) + 1.0 / (k + rank + 1)
        if key not in data:
            data[key] = h

    # 按 RRF 分数降序
    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    return [{**data[key], "rrf_score": s} for key, s in ranked]


def dedup(hits, prefix_len=80):
    """去重（按前 80 字符）"""
    seen = set()
    out = []
    for h in hits:
        sig = h["text"][:prefix_len]
        if sig not in seen:
            seen.add(sig)
            out.append(h)
    return out


class HybridRetriever:
    """
    混合检索器
    - 向量检索（语义）+ BM25（关键词）
    - RRF 融合
    """

    def __init__(self):
        self.vector_r = Retriever()
        self.bm25_r = BM25Retriever()

    def search(self, query, top_k=10):
        # 1. 向量检索 Top-10
        vec_hits = self.vector_r.search(query, top_k=top_k)

        # 2. BM25 检索 Top-10
        bm25_hits = self.bm25_r.search(query, top_k=top_k)

        # 3. RRF 融合
        merged = rrf_fusion(vec_hits, bm25_hits)

        # 4. 去重
        merged = dedup(merged)

        # 5. 返回 Top-K
        return merged[:top_k]


if __name__ == "__main__":
    from src.online.reranker import Reranker

    hr = HybridRetriever()
    rr = Reranker()

    query = "定金最多能收多少？"
    print(f"\n查询: {query}\n")

    # 混合检索
    hits = hr.search(query, top_k=10)
    print(f"=== 混合检索 Top-{len(hits)} ===")
    for i, h in enumerate(hits, 1):
        print(f"  {i}. rrf={h['rrf_score']:.4f} | {h['text'][:60]}...")

    # 精排
    reranked = rr.rerank(query, hits, top_k=3)
    print(f"\n=== 精排 Top-3 ===")
    for i, h in enumerate(reranked, 1):
        print(f"{i}. rerank={h['rerank_score']:.4f}")
        print(f"   {h['text'][:100]}...\n")
