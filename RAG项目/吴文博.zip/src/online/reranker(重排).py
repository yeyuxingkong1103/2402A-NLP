import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from config import BGE_RERANKER_PATH
from FlagEmbedding import FlagReranker


class Reranker:
    def __init__(self):
        print("加载 BGE-reranker...")
        self.model = FlagReranker(BGE_RERANKER_PATH, use_fp16=True)

    def rerank(self, query, docs, top_k=3):
        if not docs:
            return []
        pairs = [[query, d["text"]] for d in docs]
        scores = self.model.compute_score(pairs, normalize=True)
        for d, s in zip(docs, scores):
            d["rerank_score"] = float(s)
        docs.sort(key=lambda x: x["rerank_score"], reverse=True)
        return docs[:top_k]


if __name__ == "__main__":
    from src.online.retriever import Retriever
    r = Retriever()
    rr = Reranker()
    q = "定金最多能收多少？"
    hits = r.search(q, top_k=10)
    print(f"\n查询: {q}\n")
    print(f"=== 粗排 Top-{len(hits)} ===")
    for h in hits:
        print(f"  score={h['score']:.4f}  {h['source']}")
    print(f"\n=== 精排 Top-3 ===")
    reranked = rr.rerank(q, hits, top_k=3)
    for i, h in enumerate(reranked, 1):
        print(f"{i}. rerank={h['rerank_score']:.4f}")
        print(f"   {h['text'][:100]}...\n")
