# ============================================================
# 文件：bm25_retriever.py
# 作用：BM25 关键词检索（补足向量检索的"关键词精确匹配"弱项）
# ============================================================

import os, sys, json
sys.path.insert(0, "/home/lenovo/contract-rag")
from config import CHUNK_DIR

# jieba：中文分词（BM25 需要先分词）
import jieba
# rank_bm25：BM25 算法实现
from rank_bm25 import BM25Okapi


class BM25Retriever:
    """
    BM25 检索器
    - 初始化：加载分块 + jieba 分词 + 建 BM25 索引
    - search()：关键词检索
    """

    def __init__(self, chunk_path=None):
        if chunk_path is None:
            chunk_path = os.path.join(CHUNK_DIR, "all_chunks.json")

        # 1. 加载所有分块（9 块）
        with open(chunk_path, "r", encoding="utf-8") as f:
            self.chunks = json.load(f)
        print(f"BM25 加载 {len(self.chunks)} 个分块")

        # 2. jieba 分词（每块 → 词列表）
        # "定金罚则 民法典..." → ["定金", "罚则", "民法典", ...]
        self.tokenized = [list(jieba.cut(c["text"])) for c in self.chunks]

        # 3. 建 BM25 索引
        self.bm25 = BM25Okapi(self.tokenized)

    def search(self, query, top_k=10):
        """
        BM25 检索
        参数：
            query: 用户问题
            top_k: 返回条数
        返回：
            hits: 列表，每项含 text / source / chunk_id / bm25_score
        """
        # 1. 查询分词
        query_tokens = list(jieba.cut(query))

        # 2. 打分
        scores = self.bm25.get_scores(query_tokens)

        # 3. 排序（分数降序）
        idxs = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:top_k]

        # 4. 组装结果（过滤 0 分）
        hits = []
        for i in idxs:
            if scores[i] <= 0:
                continue
            hits.append({
                "text": self.chunks[i]["text"],
                "source": self.chunks[i]["source"],
                "chunk_id": self.chunks[i]["chunk_id"],
                "bm25_score": float(scores[i]),
            })
        return hits


if __name__ == "__main__":
    r = BM25Retriever()
    query = "定金最多能收多少？"
    print(f"\n查询: {query}\n")
    hits = r.search(query, top_k=5)
    for i, h in enumerate(hits, 1):
        print(f"--- 结果 {i} (bm25={h['bm25_score']:.3f}) ---")
        print(f"来源: {h['source']}")
        print(f"内容: {h['text'][:100]}...\n")
