import os, sys
sys.path.insert(0, "/home/lenovo/contract-rag")
from config import (MYSQL_HOST, MYSQL_PORT, MYSQL_USER,
                    MYSQL_PASSWORD, MYSQL_DB)
import pymysql


def get_conn():
    return pymysql.connect(
        host=MYSQL_HOST, port=MYSQL_PORT,
        user=MYSQL_USER, password=MYSQL_PASSWORD,
        database=MYSQL_DB,
        charset="utf8mb4",
        use_unicode=True,
        init_command="SET NAMES utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
    )


def get_role(role_name):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM roles WHERE name=%s", (role_name,))
            return cur.fetchone()


def list_roles():
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT id, name, description, system_prompt FROM roles")
            return cur.fetchall()


if __name__ == "__main__":
    print("📋 所有角色:")
    for r in list_roles():
        print(f"  {r['id']}. {r['name']} - {r['description']}")
        prompt = (r['system_prompt'] or '')[:50]
        print(f"     prompt: {prompt}...")

    print("\n🎭 查询'合同律师':")
    role = get_role("合同律师")
    if role:
        print(f"  name: {role['name']}")
        print(f"  prompt: {role['system_prompt'][:100]}...")
    else:
        print("  ⚠️ 不存在（需要先插入）")
