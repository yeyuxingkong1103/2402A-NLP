#!/bin/bash
cd "$(dirname "$0")/.."

echo "=========================================="
echo "  Contract RAG 系统 - 停止"
echo "=========================================="

if [ -f .api.pid ]; then
    PID=$(cat .api.pid)
    if ps -p $PID > /dev/null 2>&1; then
        kill $PID
        echo "✅ FastAPI 已停止 (PID: $PID)"
    fi
    rm -f .api.pid
else
    pkill -f "uvicorn src.api.main" && echo "✅ 已停止" || echo "⚠️ 未找到进程"
fi
