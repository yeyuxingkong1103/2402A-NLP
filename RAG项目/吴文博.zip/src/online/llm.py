import os, sys, re
sys.path.insert(0, "/home/lenovo/contract-rag")
from config import QWEN_PATH
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

_model = None
_tokenizer = None


def _load():
    global _model, _tokenizer
    if _model is None:
        print("加载 Qwen3-0.6B...")
        _tokenizer = AutoTokenizer.from_pretrained(QWEN_PATH, trust_remote_code=True)
        _model = AutoModelForCausalLM.from_pretrained(
            QWEN_PATH, dtype=torch.float16,
            device_map="cuda", trust_remote_code=True)
    return _model, _tokenizer


def chat(system_prompt, user_prompt, max_new_tokens=512):
    model, tokenizer = _load()
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]
    try:
        text = tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True,
            enable_thinking=False)
    except TypeError:
        messages[1]["content"] = "/no_think " + messages[1]["content"]
        text = tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True)
    inputs = tokenizer(text, return_tensors="pt").to("cuda")
    with torch.no_grad():
        outputs = model.generate(
            **inputs, max_new_tokens=max_new_tokens,
            do_sample=True, temperature=0.3, top_p=0.9)
    response = tokenizer.decode(
        outputs[0][inputs["input_ids"].shape[1]:],
        skip_special_tokens=True)
    response = re.sub(r"<think>.*?</think>", "", response, flags=re.DOTALL)
    response = re.sub(r"</?think>", "", response)
    return response.strip()


if __name__ == "__main__":
    reply = chat("你是专业律师", "定金最多能收多少？")
    print(reply)
