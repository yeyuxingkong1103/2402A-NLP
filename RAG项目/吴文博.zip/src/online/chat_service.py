# ============================================================
# 文件：chat_service.py
# 作用：RAG 核心调度（用混合检索）
# ============================================================

import os, sys, re, time
sys.path.insert(0, "/home/lenovo/contract-rag")

from src.online.hybrid_retriever import HybridRetriever  # ← 混合检索
from src.online.reranker import Reranker
from src.online.llm import chat
from src.memory.redis_memory import save_message, format_history
from src.memory.mysql_client import get_role

_hr = None
_rr = None


def get_hr():
    global _hr
    if _hr is None:
        _hr = HybridRetriever()
    return _hr


def get_rr():
    global _rr
    if _rr is None:
        _rr = Reranker()
    return _rr


BASE_PROMPT = """{role_prompt}

【回答要求】
1. 严格依据下方提供的法条回答用户问题
2. 引用具体法条编号
3. 语气专业、严谨
4. 不编造法条

【对话历史】
{history}

【相关法条】
{context}
"""


def clean_output(text):
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL)
    text = re.sub(r"</?think>", "", text)
    return text.strip()


def answer(user_id, question, role_name="合同律师", top_k=3):
    t0 = time.time()

    role = get_role(role_name)
    role_prompt = role["system_prompt"] if role and role.get("system_prompt") else "你是一位专业律师。"

    history = format_history(user_id, max_turns=3)

    # 混合检索（向量 + BM25 + RRF）
    hr = get_hr()
    hits = hr.search(question, top_k=10)
    print(f"混合检索: {len(hits)} 条")

    # 精排
    rr = get_rr()
    top_docs = rr.rerank(question, hits, top_k=top_k)

    context = "\n\n".join([f"【{h['source']}】{h['text']}" for h in top_docs])
    sys_prompt = BASE_PROMPT.format(role_prompt=role_prompt, history=history or "（无）", context=context)

    reply = clean_output(chat(sys_prompt, question))

    save_message(user_id, "user", question)
    save_message(user_id, "assistant", reply)

    print(f"耗时: {time.time()-t0:.2f}s")
    return reply, top_docs


if __name__ == "__main__":
    from src.memory.redis_memory import clear_history
    user = "alice"
    clear_history(user)
    q = "定金最多能收多少？"
    print(f"\n❓ 用户: {q}")
    reply, docs = answer(user, q, role_name="合同律师")
    print(f"👨‍⚖️ 律师: {reply}\n")
